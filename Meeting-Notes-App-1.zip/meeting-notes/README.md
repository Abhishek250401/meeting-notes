# Meeting Notes (Android)

Records a meeting, then uses Google Gemini to make a speaker-labelled transcript and minutes.

- Voice sample (Settings) lets Gemini tag the owner's lines; other names come from greetings like "Hi Amit" or introductions.
- Recording runs as a foreground service, so it keeps going with the screen locked.
- Audio: AAC mono 16 kHz, about 21 MB per hour, stored inside the app.
- Minutes always in English; transcript as spoken (Hindi/Marathi in Roman letters) or translated.
- Share minutes as text, or save a Word (.doc) file with minutes + transcript to Downloads/Meeting Notes.

## Build
GitHub Actions (`.github/workflows/build.yml`) unzips the newest `Meeting-Notes-App*.zip` in the repo and builds a signed debug APK.
The APK appears under the repo's Releases. A fixed keystore (`app/meeting-notes.keystore`) lets new versions install over old ones.

## Code
- `app/src/main/assets/` – UI (index.html, app.js, style.css)
- `MainActivity.java` – WebView + bridge (storage, recording, playback, sharing)
- `RecorderService.java` – foreground mic recording
- `GeminiClient.java` – uploads audio to the Gemini Files API and asks for transcript + minutes (falls back across Flash models)

/* Meeting Notes — UI logic. Native side is window.Android (see MainActivity.Bridge). */
'use strict';

const A = window.Android || makeMock();
const $ = (s) => document.querySelector(s);
const SAMPLE = '__sample';
const COLORS = ['#0E5A6B', '#C2410C', '#7C3AED', '#0F766E', '#B91C1C', '#1D4ED8', '#A16207', '#BE185D'];

let state = { settings: { userName: 'Abhishek', apiKey: '', style: 'original', model: '' }, meetings: [] };
let view = 'home';
let currentId = null;
let currentTab = 'minutes';
let recTimer = null, playTimer = null;
let liveStatus = {};      // id -> latest progress message
let seeking = false;

// ---------------- storage ----------------
function load() {
  let raw = '';
  try { raw = A.loadData(); } catch (e) {}
  let data = null;
  try { data = raw ? JSON.parse(raw) : null; } catch (e) {
    try { data = JSON.parse(A.loadBackup()); } catch (e2) {}
  }
  if (data && data.meetings) {
    state.meetings = data.meetings;
    Object.assign(state.settings, data.settings || {});
  }
}
function save() { try { A.saveData(JSON.stringify(state)); } catch (e) {} }
const meeting = (id) => state.meetings.find((m) => m.id === id);

// ---------------- helpers ----------------
function esc(s) {
  return String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
function fmtDur(ms) {
  const t = Math.max(0, Math.floor(ms / 1000)), h = Math.floor(t / 3600), m = Math.floor((t % 3600) / 60), s = t % 60;
  const pad = (n) => String(n).padStart(2, '0');
  return h ? `${h}:${pad(m)}:${pad(s)}` : `${pad(m)}:${pad(s)}`;
}
function fmtShort(ms) {
  const t = Math.max(0, Math.floor(ms / 1000)), m = Math.floor(t / 60), s = t % 60;
  return `${m}:${String(s).padStart(2, '0')}`;
}
function fmtMins(ms) { const m = Math.round(ms / 60000); return m < 1 ? '< 1 min' : m + ' min'; }
function fmtDate(ts) {
  const d = new Date(ts);
  return d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }) + ', ' +
    d.toLocaleTimeString('en-IN', { hour: 'numeric', minute: '2-digit' });
}
function tsToMs(t) {
  const p = String(t || '').split(':').map((x) => parseInt(x, 10));
  if (p.some(isNaN)) return 0;
  let ms = 0; for (const n of p) ms = ms * 60 + n; return ms * 1000;
}
function toast(msg, ms = 2200) {
  const t = $('#toast'); t.textContent = msg; t.classList.remove('hidden');
  clearTimeout(toast._t); toast._t = setTimeout(() => t.classList.add('hidden'), ms);
}
function uid() { return 'm' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6); }
function userName() { return (state.settings.userName || '').trim() || 'Me'; }

/* Parses the model's JSON; if it was cut off (very long meeting), closes it at the last complete item. */
function parseLoose(text) {
  let s = String(text || '').trim().replace(/^```(?:json)?/i, '').replace(/```$/, '').trim();
  try { return { data: JSON.parse(s), cut: false }; } catch (e) {}
  const start = s.indexOf('{'); if (start < 0) return null; s = s.slice(start);
  let inStr = false, escp = false; const stack = []; let lastSafe = -1, safeStack = null;
  for (let i = 0; i < s.length; i++) {
    const c = s[i];
    if (inStr) { if (escp) escp = false; else if (c === '\\') escp = true; else if (c === '"') inStr = false; continue; }
    if (c === '"') inStr = true;
    else if (c === '{' || c === '[') stack.push(c);
    else if (c === '}' || c === ']') stack.pop();
    else if (c === ',') { lastSafe = i; safeStack = stack.slice(); }
  }
  if (lastSafe < 0) return null;
  let fixed = s.slice(0, lastSafe);
  for (let i = safeStack.length - 1; i >= 0; i--) fixed += safeStack[i] === '{' ? '}' : ']';
  try { return { data: JSON.parse(fixed), cut: true }; } catch (e) { return null; }
}

function normalise(d) {
  d = d || {};
  const mi = d.minutes || {};
  const arr = (x) => (Array.isArray(x) ? x : x ? [x] : []);
  return {
    title: d.title || '',
    language: d.language || '',
    speakers: arr(d.speakers).map((s) => (typeof s === 'string' ? { name: s } : s)).filter((s) => s && s.name),
    transcript: arr(d.transcript).filter((x) => x && x.text),
    minutes: {
      summary: mi.summary || '',
      attendees: arr(mi.attendees).map((a) => (typeof a === 'string' ? { name: a } : a)).filter((a) => a && a.name),
      discussion: arr(mi.discussion).filter((x) => x && (x.topic || (x.points && x.points.length))),
      decisions: arr(mi.decisions).filter(Boolean),
      action_items: arr(mi.action_items).map((a) => (typeof a === 'string' ? { task: a } : a)).filter((a) => a && a.task),
      next_steps: arr(mi.next_steps).filter(Boolean),
    },
  };
}

function speakerList(m) {
  const r = m.result; if (!r) return [];
  const names = [];
  const add = (n) => { n = (n || '').trim(); if (n && !names.includes(n)) names.push(n); };
  r.speakers.forEach((s) => add(s.name));
  r.transcript.forEach((t) => add(t.speaker));
  const me = userName();
  names.sort((a, b) => (a === me ? -1 : b === me ? 1 : 0));
  return names;
}
function colorFor(m, name) {
  const list = speakerList(m); const i = list.indexOf(name);
  return COLORS[(i < 0 ? 0 : i) % COLORS.length];
}

// ---------------- views ----------------
function show(v) {
  view = v;
  ['home', 'rec', 'detail', 'settings'].forEach((x) => $('#v-' + x).classList.toggle('hidden', x !== v));
  window.scrollTo(0, 0);
  if (v === 'home') renderHome();
  if (v === 'settings') renderSettings();
  if (v !== 'detail') stopPlayback();
}

window.onBack = function () {
  if (!$('#sheet').classList.contains('hidden')) { closeSheet(); return true; }
  if (view === 'detail' || view === 'settings') { show('home'); return true; }
  return false;
};

// ---------------- home ----------------
function renderHome() {
  const s = state.settings, hasSample = safe(() => A.hasSample(), false);
  const need = [];
  if (!s.apiKey) need.push('Add your free <b>Gemini API key</b>');
  if (!hasSample) need.push('Record a 20-second <b>voice sample</b> so the app knows your voice');
  const sc = $('#setup-card');
  if (need.length) {
    sc.innerHTML = `<b>Finish setup</b><ol>${need.map((n) => `<li>${n}</li>`).join('')}</ol>
      <button class="btn primary sm" id="go-setup">Open settings</button>`;
    sc.classList.remove('hidden');
    $('#go-setup').onclick = () => show('settings');
  } else sc.classList.add('hidden');

  const list = $('#list');
  const ms = state.meetings.slice().sort((a, b) => b.createdAt - a.createdAt);
  if (!ms.length) { list.innerHTML = '<div class="empty">No meetings yet. Tap <b>Start recording</b> when your meeting begins.</div>'; return; }
  list.innerHTML = ms.map((m) => {
    const st = statusPill(m);
    const people = m.result ? speakerList(m).filter((n) => n !== userName()).slice(0, 3).join(', ') : '';
    return `<button class="m-item" data-id="${m.id}">
      <div class="m-top"><div class="m-title">${esc(m.title || 'Untitled meeting')}</div>${st}</div>
      <div class="m-sub">${fmtDate(m.createdAt)} · ${fmtMins(m.durationMs || 0)}${people ? ' · with ' + esc(people) : ''}</div>
    </button>`;
  }).join('');
  list.querySelectorAll('.m-item').forEach((b) => (b.onclick = () => openMeeting(b.dataset.id)));
}
function statusPill(m) {
  if (m.status === 'processing') return '<span class="pill busy">Making notes…</span>';
  if (m.status === 'error') return '<span class="pill err">Failed</span>';
  if (m.status === 'done') return '<span class="pill ok">Ready</span>';
  return '<span class="pill warn">Not processed</span>';
}
function safe(fn, d) { try { return fn(); } catch (e) { return d; } }

// ---------------- recording ----------------
let recId = null;
let lastRecMs = 0;

function startRecording() {
  if (!safe(() => A.hasMic(), false)) {
    window.onPermission = (ok) => { window.onPermission = null; if (ok) startRecording(); else toast('Mic permission is needed to record.'); };
    A.requestMic(); return;
  }
  const id = uid();
  const err = A.startRecording(id);
  if (err) { toast(err, 3500); return; }
  const m = {
    id, createdAt: Date.now(), durationMs: 0, status: 'recording',
    title: $('#in-title').value.trim(), hints: $('#in-hints').value.trim(),
  };
  state.meetings.push(m); save();
  $('#in-title').value = ''; $('#in-hints').value = ''; $('details.opt').open = false;
  recId = id; lastRecMs = 0;
  enterRecView();
}

function enterRecView() {
  show('rec');
  $('#rec-tip').innerHTML = `Start by greeting people by name, like <b>"Hi Amit"</b>, so the notes show who said what. You can lock the phone — recording continues.`;
  const meter = $('#meter');
  meter.innerHTML = Array.from({ length: 24 }, () => '<i></i>').join('');
  clearInterval(recTimer);
  recTimer = setInterval(tickRec, 150);
  tickRec();
}

const levels = new Array(24).fill(0);
function tickRec() {
  const st = safe(() => JSON.parse(A.recStatus()), { active: false });
  if (!st.active) {
    if (st.error) { clearInterval(recTimer); toast(st.error, 4000); finishFailedStart(); }
    else if (recId && lastRecMs > 0) { stopRecording(); } // recorder stopped by the system: keep what we have
    return;
  }
  lastRecMs = st.ms;
  $('#rec-time').textContent = fmtDur(st.ms);
  $('#rec-label').textContent = st.paused ? 'Paused' : 'Recording';
  $('#rec-label').classList.toggle('paused', !!st.paused);
  $('#btn-pause').textContent = st.paused ? 'Resume' : 'Pause';
  const lvl = st.paused ? 0 : Math.min(1, Math.sqrt((st.amp || 0) / 20000));
  levels.shift(); levels.push(lvl);
  $('#meter').querySelectorAll('i').forEach((el, i) => (el.style.height = 6 + levels[i] * 50 + 'px'));
}

function finishFailedStart() {
  if (!recId) { show('home'); return; }
  state.meetings = state.meetings.filter((m) => m.id !== recId); save();
  recId = null; show('home');
}

function stopRecording() {
  clearInterval(recTimer);
  const ms = A.stopRec();
  const m = meeting(recId);
  recId = null;
  if (!m) { show('home'); return; }
  m.durationMs = ms > 0 ? ms : Math.max(m.durationMs || 0, lastRecMs);
  lastRecMs = 0;
  if (m.durationMs < 3000) {
    state.meetings = state.meetings.filter((x) => x.id !== m.id);
    safe(() => A.deleteMeetingFiles(m.id)); save();
    toast('Recording too short, not saved.'); show('home'); return;
  }
  m.status = 'recorded'; save();
  openMeeting(m.id);
  if (state.settings.apiKey) processMeeting(m.id);
}

function discardRecording() {
  confirmSheet('Discard this recording?', 'The audio will be deleted.', 'Discard', () => {
    clearInterval(recTimer);
    A.stopRec();
    if (recId) { safe(() => A.deleteMeetingFiles(recId)); state.meetings = state.meetings.filter((m) => m.id !== recId); save(); }
    recId = null; show('home');
  });
}

// ---------------- AI processing ----------------
function processMeeting(id) {
  const m = meeting(id); if (!m) return;
  const s = state.settings;
  if (!s.apiKey) { toast('Add your Gemini API key in Settings first.', 3000); show('settings'); return; }
  m.status = 'processing'; m.error = ''; save();
  liveStatus[id] = 'Starting…';
  A.keepScreenOn(true);
  A.process(id, s.apiKey, userName(), m.hints || '', s.style || 'original', s.model || '', m.durationMs || 0);
  if (view === 'detail' && currentId === id) renderDetail();
}

window.onProcessStatus = function (id, msg) {
  liveStatus[id] = msg;
  if (view === 'detail' && currentId === id) {
    const el = document.querySelector('#d-status .msg'); if (el) el.textContent = msg;
  }
};

window.onProcessDone = function (id, out) {
  A.keepScreenOn(false);
  applyResult(id, out);
  if (view === 'detail' && currentId === id) renderDetail();
  else if (view === 'home') renderHome();
  const m = meeting(id);
  if (m && m.status === 'done') toast('Notes ready ✓');
};

window.onProcessError = function (id, msg) {
  A.keepScreenOn(false);
  const m = meeting(id); if (!m) return;
  m.status = m.result ? 'done' : 'error'; m.error = msg; save();
  if (view === 'detail' && currentId === id) renderDetail();
  else if (view === 'home') renderHome();
  if (m.result) toast(msg, 4000);
};

function applyResult(id, out) {
  const m = meeting(id); if (!m) return;
  let wrap; try { wrap = JSON.parse(out); } catch (e) { wrap = { text: out }; }
  const parsed = parseLoose(wrap.text);
  if (!parsed) { m.status = 'error'; m.error = 'The AI answer could not be read. Tap "Try again".'; save(); return; }
  m.result = normalise(parsed.data);
  m.cut = parsed.cut || wrap.finish === 'MAX_TOKENS';
  if (!m.title && m.result.title) m.title = m.result.title;
  m.status = 'done'; m.error = ''; save();
}

/* After the app was closed mid-processing, pick up saved results. */
function recoverProcessing() {
  state.meetings.forEach((m) => {
    if (m.status === 'recording') {
      const st = safe(() => JSON.parse(A.recStatus()), { active: false });
      if (st.active && st.id === m.id) { recId = m.id; return; }
      m.status = 'recorded';
      if (!m.durationMs) m.durationMs = 0;
    }
    if (m.status === 'processing' && !safe(() => A.isProcessing(m.id), false)) {
      const out = safe(() => A.getResult(m.id), '');
      if (out) applyResult(m.id, out);
      else { m.status = 'error'; m.error = 'Processing was interrupted (app was closed). Tap "Try again".'; }
    }
  });
  save();
}

window.onAppResume = function () {
  if (view === 'home') renderHome();
};

// ---------------- detail ----------------
function openMeeting(id) {
  currentId = id; currentTab = 'minutes';
  show('detail'); renderDetail();
}

function renderDetail() {
  const m = meeting(currentId); if (!m) { show('home'); return; }
  $('#d-title').textContent = m.title || 'Untitled meeting';
  const sz = safe(() => A.audioSize(m.id), 0);
  $('#d-meta').textContent = `${fmtDate(m.createdAt)} · ${fmtDur(m.durationMs || 0)}${m.result && m.result.language ? ' · ' + m.result.language : ''}${sz ? '' : ' · audio deleted'}`;
  $('#p-time').textContent = fmtShort(m.durationMs || 0);

  const st = $('#d-status');
  if (m.status === 'processing') {
    st.className = 'card status';
    st.innerHTML = `<div class="spin"></div><div class="grow"><p><b>Making notes</b></p><p class="msg hint">${esc(liveStatus[m.id] || 'Working…')}</p>
      <p class="hint">Keep the app open. A 1-hour meeting takes about 2–4 minutes.</p></div>`;
  } else if (m.status === 'error' || (m.error && m.status === 'done')) {
    st.className = 'card status err';
    st.innerHTML = `<div class="grow"><p><b>Couldn't make notes</b></p><p>${esc(m.error)}</p>
      <button class="btn primary sm" id="btn-retry">Try again</button></div>`;
    $('#btn-retry').onclick = () => processMeeting(m.id);
  } else if (m.status === 'recorded' || !m.result) {
    st.className = 'card status';
    st.innerHTML = `<div class="grow"><p><b>Recording saved</b></p><p class="hint">Make the transcript and minutes now.</p>
      <button class="btn primary sm" id="btn-make">Make notes</button></div>`;
    $('#btn-make').onclick = () => processMeeting(m.id);
  } else st.className = 'card status hidden';

  const body = $('#d-body');
  if (!m.result) { body.classList.add('hidden'); return; }
  body.classList.remove('hidden');
  renderSpeakers(m);
  renderMinutes(m);
  renderTranscript(m);
  setTab(currentTab);
}

function renderSpeakers(m) {
  const names = speakerList(m);
  const ident = {}; m.result.speakers.forEach((s) => (ident[s.name] = s.identified_by || ''));
  $('#speakers').innerHTML = names.map((n) =>
    `<button class="spk" data-n="${esc(n)}"><span class="dot" style="background:${colorFor(m, n)}"></span>${esc(n)}${n === userName() ? ' <small>(you)</small>' : ''}</button>`
  ).join('') + `<span class="hint" style="align-self:center">Tap a name to fix it</span>`;
  $('#speakers').querySelectorAll('.spk').forEach((b) => (b.onclick = () => renameSheet(m, b.dataset.n)));
}

function renderMinutes(m) {
  const r = m.result, mi = r.minutes;
  let h = '<div class="mins">';
  if (m.cut) h += '<div class="note">This meeting was very long, so the transcript may stop a little before the end. The minutes cover the full meeting.</div>';
  if (mi.summary) h += `<div class="card"><h3>Summary</h3><p>${esc(mi.summary)}</p></div>`;
  if (mi.attendees.length) h += `<div class="card"><h3>Attendees</h3><div class="att">${mi.attendees.map((a) =>
    `<span>${esc(a.name)}${a.role ? ` <small>· ${esc(a.role)}</small>` : ''}</span>`).join('')}</div></div>`;
  if (mi.discussion.length) h += `<div class="card"><h3>Discussion</h3>${mi.discussion.map((d) =>
    `${d.topic ? `<h4>${esc(d.topic)}</h4>` : ''}<ul>${(d.points || []).filter(Boolean).map((p) => `<li>${esc(p)}</li>`).join('')}</ul>`).join('')}</div>`;
  if (mi.decisions.length) h += `<div class="card"><h3>Decisions</h3><ul>${mi.decisions.map((d) => `<li>${esc(d)}</li>`).join('')}</ul></div>`;
  if (mi.action_items.length) h += `<div class="card"><h3>Action items</h3>${mi.action_items.map((a) =>
    `<div class="ai"><div class="box"></div><div><div>${esc(a.task)}</div>
      <div class="who">${a.owner ? `Owner: <b>${esc(a.owner)}</b>` : 'Owner: —'}${a.due ? ` · Due: <b>${esc(a.due)}</b>` : ''}</div></div></div>`).join('')}</div>`;
  if (mi.next_steps.length) h += `<div class="card"><h3>Next steps</h3><ul>${mi.next_steps.map((d) => `<li>${esc(d)}</li>`).join('')}</ul></div>`;
  if (h === '<div class="mins">') h += '<div class="empty">No minutes were produced.</div>';
  $('#tab-minutes').innerHTML = h + '</div>';
}

function renderTranscript(m) {
  const t = m.result.transcript;
  if (!t.length) { $('#tab-transcript').innerHTML = '<div class="empty">No transcript.</div>'; return; }
  $('#tab-transcript').innerHTML = '<div class="card">' + t.map((x) => `<div class="ts-item">
      <div class="ts-bar" style="background:${colorFor(m, x.speaker)}"></div>
      <div><div class="ts-head"><b style="color:${colorFor(m, x.speaker)}">${esc(x.speaker || '?')}</b>
      ${x.t ? `<button data-t="${esc(x.t)}">${esc(x.t)}</button>` : ''}</div>
      <div class="ts-text">${esc(x.text)}</div></div></div>`).join('') + '</div>';
  $('#tab-transcript').querySelectorAll('.ts-head button').forEach((b) => (b.onclick = () => playFrom(tsToMs(b.dataset.t))));
}

function setTab(t) {
  currentTab = t;
  document.querySelectorAll('.tab').forEach((b) => b.classList.toggle('on', b.dataset.tab === t));
  $('#tab-minutes').classList.toggle('hidden', t !== 'minutes');
  $('#tab-transcript').classList.toggle('hidden', t !== 'transcript');
}

// ----- rename speakers -----
function renameSheet(m, oldName) {
  const others = speakerList(m).filter((n) => n !== oldName);
  openSheet(`<h3>Rename "${esc(oldName)}"</h3>
    <p>Changes this name everywhere in the transcript and minutes.</p>
    <input id="rn-in" value="${esc(oldName)}">
    ${others.length ? `<p class="hint" style="margin-top:10px">Or merge into:</p><div class="chips">${others.map((n) => `<button data-n="${esc(n)}">${esc(n)}</button>`).join('')}</div>` : ''}
    ${oldName !== userName() ? `<div class="chips"><button data-n="${esc(userName())}" ${others.includes(userName()) ? 'hidden' : ''}>This is me (${esc(userName())})</button></div>` : ''}
    <div class="acts"><button class="btn ghost" id="rn-cancel">Cancel</button><button class="btn primary" id="rn-ok">Save</button></div>`);
  const inp = $('#rn-in'); setTimeout(() => inp.select(), 50);
  $('#rn-cancel').onclick = closeSheet;
  $('#rn-ok').onclick = () => { const v = inp.value.trim(); if (v) { renameSpeaker(m, oldName, v); } closeSheet(); };
  $('#sheet').querySelectorAll('.chips button').forEach((b) => (b.onclick = () => { renameSpeaker(m, oldName, b.dataset.n); closeSheet(); }));
}

function renameSpeaker(m, from, to) {
  if (!to || from === to) return;
  const r = m.result;
  const swap = (s) => (s === from ? to : s);
  const re = new RegExp('\\b' + from.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\b', 'g');
  const txt = (s) => (typeof s === 'string' ? s.replace(re, to) : s);
  r.transcript.forEach((x) => (x.speaker = swap(x.speaker)));
  const seen = new Set();
  r.speakers = r.speakers.map((s) => ({ ...s, name: swap(s.name) })).filter((s) => !seen.has(s.name) && seen.add(s.name));
  const mi = r.minutes;
  mi.summary = txt(mi.summary);
  const seenA = new Set();
  mi.attendees = mi.attendees.map((a) => ({ ...a, name: swap(a.name) })).filter((a) => !seenA.has(a.name) && seenA.add(a.name));
  mi.discussion.forEach((d) => { d.topic = txt(d.topic); d.points = (d.points || []).map(txt); });
  mi.decisions = mi.decisions.map(txt);
  mi.next_steps = mi.next_steps.map(txt);
  mi.action_items.forEach((a) => { a.owner = swap(a.owner); a.task = txt(a.task); });
  save(); renderDetail(); toast(`Renamed to ${to}`);
}

// ----- more menu -----
function moreMenu() {
  const m = meeting(currentId); if (!m) return;
  openSheet(`<h3>${esc(m.title || 'Untitled meeting')}</h3>
    <button class="menu-item" id="mm-title">Rename meeting</button>
    ${m.result ? '<button class="menu-item" id="mm-redo">Make notes again</button>' : ''}
    ${m.result ? '<button class="menu-item" id="mm-copy">Share transcript only</button>' : ''}
    <button class="menu-item danger" id="mm-del">Delete meeting</button>`);
  $('#mm-title').onclick = () => {
    openSheet(`<h3>Meeting title</h3><input id="mt-in" value="${esc(m.title || '')}">
      <div class="acts"><button class="btn ghost" id="mt-c">Cancel</button><button class="btn primary" id="mt-ok">Save</button></div>`);
    $('#mt-c').onclick = closeSheet;
    $('#mt-ok').onclick = () => { m.title = $('#mt-in').value.trim(); save(); closeSheet(); renderDetail(); };
  };
  if (m.result) {
    $('#mm-redo').onclick = () => {
      confirmSheet('Make notes again?', 'Any names you fixed will be replaced by the new result.', 'Redo', () => processMeeting(m.id));
    };
    $('#mm-copy').onclick = () => { closeSheet(); A.shareText((m.title || 'Meeting') + ' – transcript', transcriptText(m)); };
  }
  $('#mm-del').onclick = () => confirmSheet('Delete this meeting?', 'The audio, transcript and minutes will be deleted.', 'Delete', () => {
    stopPlayback();
    safe(() => A.deleteMeetingFiles(m.id));
    state.meetings = state.meetings.filter((x) => x.id !== m.id); save();
    show('home');
  });
}

// ---------------- sheets ----------------
function openSheet(html) {
  $('#sheet').innerHTML = html;
  $('#sheet').classList.remove('hidden'); $('#scrim').classList.remove('hidden');
}
function closeSheet() { $('#sheet').classList.add('hidden'); $('#scrim').classList.add('hidden'); }
function confirmSheet(title, text, okLabel, onOk) {
  openSheet(`<h3>${esc(title)}</h3><p>${esc(text)}</p>
    <div class="acts"><button class="btn ghost" id="cf-c">Cancel</button><button class="btn danger" id="cf-ok">${esc(okLabel)}</button></div>`);
  $('#cf-c').onclick = closeSheet;
  $('#cf-ok').onclick = () => { closeSheet(); onOk(); };
}

// ---------------- playback ----------------
function togglePlay() {
  const err = A.play(currentId);
  if (err) { toast(err); return; }
  startPlayTimer();
}
function playFrom(ms) {
  const ps = safe(() => JSON.parse(A.playState()), {});
  if (ps.id !== currentId || !ps.playing) { const err = A.play(currentId); if (err) { toast(err); return; } }
  A.seek(Math.max(0, ms - 1000));
  startPlayTimer();
  window.scrollTo({ top: 0, behavior: 'smooth' });
}
function startPlayTimer() { clearInterval(playTimer); playTimer = setInterval(tickPlay, 300); tickPlay(); }
function tickPlay() {
  const ps = safe(() => JSON.parse(A.playState()), { playing: false });
  $('#ic-play').innerHTML = ps.playing ? '<path d="M7 5h4v14H7zM13 5h4v14h-4z"/>' : '<path d="M8 5v14l11-7z"/>';
  if (ps.dur > 0 && !seeking) {
    $('#seek').value = Math.round((ps.pos / ps.dur) * 1000);
    $('#p-time').textContent = fmtShort(ps.pos) + ' / ' + fmtShort(ps.dur);
  }
  if (!ps.playing && ps.id !== currentId) clearInterval(playTimer);
}
function stopPlayback() {
  clearInterval(playTimer); safe(() => A.stopPlay());
  const ic = $('#ic-play'); if (ic) ic.innerHTML = '<path d="M8 5v14l11-7z"/>';
  const sk = $('#seek'); if (sk) sk.value = 0;
}
window.onPlayEnd = () => { tickPlay(); };

// ---------------- export ----------------
function minutesText(m) {
  const r = m.result, mi = r.minutes, L = [];
  L.push(`*${m.title || 'Meeting'}*`);
  L.push(`${fmtDate(m.createdAt)} · ${fmtDur(m.durationMs || 0)}`);
  if (mi.attendees.length) L.push('', '*Attendees*', mi.attendees.map((a) => a.name + (a.role ? ` (${a.role})` : '')).join(', '));
  if (mi.summary) L.push('', '*Summary*', mi.summary);
  if (mi.discussion.length) {
    L.push('', '*Discussion*');
    mi.discussion.forEach((d) => { if (d.topic) L.push(`_${d.topic}_`); (d.points || []).forEach((p) => L.push(`• ${p}`)); });
  }
  if (mi.decisions.length) { L.push('', '*Decisions*'); mi.decisions.forEach((d) => L.push(`• ${d}`)); }
  if (mi.action_items.length) {
    L.push('', '*Action items*');
    mi.action_items.forEach((a) => L.push(`• ${a.task}${a.owner ? ` — ${a.owner}` : ''}${a.due ? ` (by ${a.due})` : ''}`));
  }
  if (mi.next_steps.length) { L.push('', '*Next steps*'); mi.next_steps.forEach((d) => L.push(`• ${d}`)); }
  return L.join('\n');
}
function transcriptText(m) {
  return `${m.title || 'Meeting'} – transcript\n${fmtDate(m.createdAt)}\n\n` +
    m.result.transcript.map((x) => `[${x.t || ''}] ${x.speaker}: ${x.text}`).join('\n\n');
}

function wordHtml(m) {
  const r = m.result, mi = r.minutes;
  const li = (a) => a.map((x) => `<li>${esc(x)}</li>`).join('');
  let h = `<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns="http://www.w3.org/TR/REC-html40">
<head><meta charset="utf-8"><title>${esc(m.title || 'Minutes')}</title>
<style>body{font-family:Calibri,Arial,sans-serif;font-size:11pt;color:#14232B}
h1{font-size:18pt;color:#0E5A6B;margin:0 0 4pt}h2{font-size:12.5pt;color:#0E5A6B;border-bottom:1pt solid #C9D6DD;padding-bottom:2pt;margin:16pt 0 6pt}
h3{font-size:11pt;margin:8pt 0 2pt}.meta{color:#5B6B74;margin:0 0 6pt}
table{border-collapse:collapse;width:100%}td,th{border:1pt solid #C9D6DD;padding:4pt 6pt;vertical-align:top;font-size:10.5pt}th{background:#E3F0F2;text-align:left}
.sp{font-weight:bold}.ts{color:#5B6B74;font-size:9pt}p.t{margin:0 0 6pt}</style></head><body>`;
  h += `<h1>${esc(m.title || 'Minutes of Meeting')}</h1><p class="meta">${esc(fmtDate(m.createdAt))} · Duration ${esc(fmtDur(m.durationMs || 0))}</p>`;
  if (mi.attendees.length) h += `<h2>Attendees</h2><p>${mi.attendees.map((a) => esc(a.name) + (a.role ? ` (${esc(a.role)})` : '')).join(', ')}</p>`;
  if (mi.summary) h += `<h2>Summary</h2><p>${esc(mi.summary)}</p>`;
  if (mi.discussion.length) h += `<h2>Discussion</h2>` + mi.discussion.map((d) => `${d.topic ? `<h3>${esc(d.topic)}</h3>` : ''}<ul>${li((d.points || []).filter(Boolean))}</ul>`).join('');
  if (mi.decisions.length) h += `<h2>Decisions</h2><ul>${li(mi.decisions)}</ul>`;
  if (mi.action_items.length) h += `<h2>Action items</h2><table><tr><th>#</th><th>Task</th><th>Owner</th><th>Due</th></tr>` +
    mi.action_items.map((a, i) => `<tr><td>${i + 1}</td><td>${esc(a.task)}</td><td>${esc(a.owner || '')}</td><td>${esc(a.due || '')}</td></tr>`).join('') + '</table>';
  if (mi.next_steps.length) h += `<h2>Next steps</h2><ul>${li(mi.next_steps)}</ul>`;
  if (r.transcript.length) {
    h += `<br style="page-break-before:always"><h2>Transcript</h2>`;
    h += r.transcript.map((x) => `<p class="t"><span class="sp" style="color:${colorFor(m, x.speaker)}">${esc(x.speaker)}</span> <span class="ts">${esc(x.t || '')}</span><br>${esc(x.text)}</p>`).join('');
  }
  return h + '</body></html>';
}

function fileSafe(s) { return String(s || 'Meeting').replace(/[\\/:*?"<>|]+/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 60); }

function shareMenu() {
  const m = meeting(currentId); if (!m || !m.result) return;
  openSheet(`<h3>Share</h3>
    <button class="menu-item" id="sh-text">Minutes as message (WhatsApp, email)</button>
    <button class="menu-item" id="sh-word">Minutes + transcript as Word file</button>
    <button class="menu-item" id="sh-tr">Transcript as message</button>`);
  $('#sh-text').onclick = () => { closeSheet(); A.shareText(m.title || 'Meeting minutes', minutesText(m)); };
  $('#sh-tr').onclick = () => { closeSheet(); A.shareText((m.title || 'Meeting') + ' – transcript', transcriptText(m)); };
  $('#sh-word').onclick = () => { closeSheet(); const uri = saveWord(m, true); if (uri) A.shareFile(uri, 'application/msword', m.title || 'Meeting minutes'); };
}

function saveWord(m, quiet) {
  const d = new Date(m.createdAt);
  const stamp = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')} ${String(d.getHours()).padStart(2, '0')}${String(d.getMinutes()).padStart(2, '0')}`;
  const name = `MoM - ${fileSafe(m.title)} - ${stamp}.doc`;
  const uri = A.saveDownload(name, 'application/msword', wordHtml(m));
  if (!uri) { toast('Could not save the file.'); return ''; }
  if (!quiet) toast('Saved to Downloads › Meeting Notes', 3000);
  return uri;
}

// ---------------- settings ----------------
let sampleTimer = null;
function renderSettings() {
  const s = state.settings;
  $('#s-name').value = s.userName || '';
  $('#s-key').value = s.apiKey || '';
  $('#s-style').value = s.style || 'original';
  $('#s-model').value = s.model || '';
  document.querySelectorAll('#s-script .nm').forEach((e) => (e.textContent = userName()));
  updateSampleState();
  $('#s-foot').textContent = `${state.meetings.length} meeting${state.meetings.length === 1 ? '' : 's'} saved on this phone · v1.0`;
}
function updateSampleState() {
  const has = safe(() => A.hasSample(), false);
  const p = $('#s-sample-state');
  p.textContent = has ? 'Saved' : 'Not recorded'; p.className = 'pill ' + (has ? 'ok' : 'warn');
  $('#s-play-sample').disabled = !has;
  $('#s-rec-sample').textContent = has ? 'Record again' : 'Record sample';
}
function saveSettings() {
  const s = state.settings;
  s.userName = $('#s-name').value.trim();
  s.apiKey = $('#s-key').value.trim();
  s.style = $('#s-style').value;
  s.model = $('#s-model').value.trim();
  document.querySelectorAll('#s-script .nm').forEach((e) => (e.textContent = userName()));
  save();
}
function toggleSampleRec() {
  const st = safe(() => JSON.parse(A.recStatus()), { active: false });
  if (st.active && st.id === SAMPLE) {
    clearInterval(sampleTimer);
    const ms = A.stopRec();
    $('#s-sample-time').textContent = '';
    if (ms < 8000) toast('Too short — please record at least 10 seconds.', 3000);
    else toast('Voice sample saved ✓');
    updateSampleState(); return;
  }
  if (st.active) { toast('A meeting is being recorded.'); return; }
  if (!safe(() => A.hasMic(), false)) {
    window.onPermission = (ok) => { window.onPermission = null; if (ok) toggleSampleRec(); else toast('Mic permission is needed.'); };
    A.requestMic(); return;
  }
  safe(() => A.stopPlay());
  const err = A.startRecording(SAMPLE);
  if (err) { toast(err); return; }
  $('#s-rec-sample').textContent = 'Stop';
  clearInterval(sampleTimer);
  sampleTimer = setInterval(() => {
    const s2 = safe(() => JSON.parse(A.recStatus()), { active: false });
    if (!s2.active) { clearInterval(sampleTimer); if (s2.error) toast(s2.error); updateSampleState(); return; }
    $('#s-sample-time').textContent = '● ' + fmtShort(s2.ms);
    if (s2.ms > 45000) toggleSampleRec();
  }, 250);
}

// ---------------- wire up ----------------
function wire() {
  $('#btn-settings').onclick = () => show('settings');
  $('#btn-record').onclick = startRecording;
  $('#btn-pause').onclick = () => {
    const st = safe(() => JSON.parse(A.recStatus()), {});
    if (st.paused) A.resumeRec(); else A.pauseRec();
    tickRec();
  };
  $('#btn-stop').onclick = stopRecording;
  $('#btn-discard').onclick = discardRecording;
  $('#btn-back').onclick = () => show('home');
  $('#btn-sback').onclick = () => show('home');
  $('#btn-more').onclick = moreMenu;
  $('#btn-play').onclick = togglePlay;
  $('#btn-share').onclick = shareMenu;
  $('#btn-word').onclick = () => { const m = meeting(currentId); if (m && m.result) saveWord(m, false); };
  $('#scrim').onclick = closeSheet;
  document.querySelectorAll('.tab').forEach((b) => (b.onclick = () => setTab(b.dataset.tab)));
  const sk = $('#seek');
  sk.oninput = () => { seeking = true; };
  sk.onchange = () => {
    const ps = safe(() => JSON.parse(A.playState()), {});
    if (ps.id !== currentId) { const e = A.play(currentId); if (e) { toast(e); seeking = false; return; } startPlayTimer(); }
    const ps2 = safe(() => JSON.parse(A.playState()), {});
    if (ps2.dur > 0) A.seek(Math.round((sk.value / 1000) * ps2.dur));
    seeking = false;
  };
  ['#s-name', '#s-key', '#s-model'].forEach((s) => ($(s).oninput = saveSettings));
  $('#s-style').onchange = saveSettings;
  $('#s-getkey').onclick = () => A.openUrl('https://aistudio.google.com/apikey');
  $('#s-showkey').onclick = () => {
    const k = $('#s-key'); const hide = k.type === 'text';
    k.type = hide ? 'password' : 'text'; $('#s-showkey').textContent = hide ? 'Show' : 'Hide';
  };
  $('#s-rec-sample').onclick = toggleSampleRec;
  $('#s-play-sample').onclick = () => { const e = A.play(SAMPLE); if (e) toast(e); };
}

// ---------------- mock (browser testing only) ----------------
function makeMock() {
  let rec = null, data = localStorage.getItem('mock') || '', sample = false, playing = null;
  const results = {};
  return {
    loadData: () => data, loadBackup: () => data, saveData: (j) => { data = j; localStorage.setItem('mock', j); return true; },
    getResult: (id) => results[id] || '', deleteMeetingFiles: () => {}, audioSize: () => 1000,
    hasSample: () => sample, hasMic: () => true, requestMic: () => setTimeout(() => window.onPermission(true), 10),
    startRecording: (id) => { rec = { id, t0: Date.now(), acc: 0, paused: false }; return ''; },
    recStatus: () => JSON.stringify(rec ? { active: true, id: rec.id, paused: rec.paused, ms: rec.acc + (rec.paused ? 0 : Date.now() - rec.t0), amp: Math.random() * 15000, error: '' } : { active: false, error: '' }),
    pauseRec: () => { rec.acc += Date.now() - rec.t0; rec.paused = true; return true; },
    resumeRec: () => { rec.t0 = Date.now(); rec.paused = false; return true; },
    stopRec: () => { if (!rec) return -1; const ms = rec.acc + (rec.paused ? 0 : Date.now() - rec.t0) + (window.MOCK_EXTRA || 0); if (rec.id === SAMPLE) sample = true; rec = null; return ms; },
    play: (id) => { playing = playing === id ? null : id; return ''; }, stopPlay: () => { playing = null; }, seek: () => {},
    playState: () => JSON.stringify({ id: playing || '', playing: !!playing, pos: 12000, dur: 1800000 }),
    isProcessing: () => false,
    process: (id) => {
      setTimeout(() => window.onProcessStatus(id, 'Uploading recording… 40%'), 300);
      setTimeout(() => { const out = JSON.stringify({ text: JSON.stringify(window.MOCK_RESULT || {}), finish: 'STOP' }); results[id] = out; window.onProcessDone(id, out); }, window.MOCK_DELAY || 900);
    },
    saveDownload: (n) => { window.LAST_SAVE = n; return 'content://x'; }, shareFile: () => {}, shareText: (s, t) => { window.LAST_SHARE = t; },
    openUrl: () => {}, keepScreenOn: () => {},
  };
}

// ---------------- start ----------------
load();
recoverProcessing();
wire();
if (recId) enterRecView(); else show('home');

package com.abhi.meetingnotes;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashSet;

/** Sends the recording (plus the owner's voice sample) to Gemini and gets back transcript + minutes as JSON. */
public class GeminiClient {

    public interface Listener {
        void status(String msg);
    }

    public static class ApiException extends Exception {
        public final int code;
        public ApiException(int code, String msg) { super(msg); this.code = code; }
    }

    private static final String BASE = "https://generativelanguage.googleapis.com";
    // Tried in order if a model is missing or busy. "gemini-flash-latest" always points to Google's newest Flash.
    private static final String[] FALLBACK_MODELS = {
            "gemini-flash-latest", "gemini-3.5-flash", "gemini-3-flash-preview",
            "gemini-3.1-flash-lite", "gemini-flash-lite-latest"
    };

    private final String apiKey;
    private final Listener listener;

    public GeminiClient(String apiKey, Listener listener) {
        this.apiKey = apiKey.trim();
        this.listener = listener;
    }

    /** Returns the model's JSON text. Throws with a plain-English message on failure. */
    public String process(File meetingAudio, File voiceSample, String userName, String hints,
                          String style, String preferredModel, long durationMs) throws Exception {
        listener.status("Uploading recording…");
        String meetingUri = uploadAndWait(meetingAudio, "meeting");
        String sampleUri = null;
        if (voiceSample != null && voiceSample.exists() && voiceSample.length() > 2000) {
            listener.status("Uploading your voice sample…");
            sampleUri = uploadAndWait(voiceSample, "voice-sample");
        }

        JSONArray parts = new JSONArray();
        if (sampleUri != null) {
            parts.put(text("AUDIO 1 is a short voice sample of " + userName
                    + ". He owns this app and recorded the meeting."));
            parts.put(file(sampleUri));
            parts.put(text("AUDIO 2 is the full meeting recording."));
        } else {
            parts.put(text("This is the meeting recording. It was recorded by " + userName
                    + " (no voice sample was given, so work out which speaker he is from context: "
                    + "he is usually the one who greets the others first)."));
        }
        parts.put(file(meetingUri));
        parts.put(text(buildPrompt(userName, hints, style, sampleUri != null, durationMs)));

        JSONObject body = new JSONObject();
        JSONArray contents = new JSONArray();
        contents.put(new JSONObject().put("role", "user").put("parts", parts));
        body.put("contents", contents);
        JSONObject gen = new JSONObject();
        gen.put("responseMimeType", "application/json");
        gen.put("temperature", 0.2);
        gen.put("maxOutputTokens", 65536);
        body.put("generationConfig", gen);

        LinkedHashSet<String> models = new LinkedHashSet<>();
        if (preferredModel != null && !preferredModel.trim().isEmpty()) models.add(preferredModel.trim());
        for (String m : FALLBACK_MODELS) models.add(m);

        ApiException last = null;
        for (String model : models) {
            listener.status("Writing transcript and minutes (" + model + ")… this can take 1–3 min");
            try {
                String resp = postJson(BASE + "/v1beta/models/" + model + ":generateContent?key="
                        + enc(apiKey), body.toString(), 15 * 60 * 1000);
                return extractText(resp);
            } catch (ApiException e) {
                last = e;
                // Try the next model only when this one is missing or busy / over its limit.
                if (e.code == 404 || e.code == 429 || e.code == 500 || e.code == 503) continue;
                throw new Exception(friendly(e));
            }
        }
        throw new Exception(last == null ? "Something went wrong." : friendly(last));
    }

    private String buildPrompt(String user, String hints, String style, boolean hasSample, long durationMs) {
        StringBuilder p = new StringBuilder();
        p.append("You are an expert meeting secretary. Listen to the meeting carefully and produce a full transcript and minutes.\n\n");
        p.append("WHO IS SPEAKING\n");
        if (hasSample) {
            p.append("- Compare voices with AUDIO 1. Every line spoken in that voice is \"").append(user).append("\".\n");
        } else {
            p.append("- Label the app owner's lines as \"").append(user).append("\".\n");
        }
        p.append("- Find the names of the other people from how they are addressed. Example: if ").append(user)
         .append(" says \"Hi Amit\", \"Thanks Amit\" or \"Amit, what do you think?\", the person who replies is Amit. ")
         .append("Also use self-introductions (\"I'm Priya from ACC\") and names used by others.\n");
        p.append("- Keep each person's label the same for the whole meeting. Use the name as said (first name is fine).\n");
        p.append("- If you can't find a person's name, call them \"Speaker 2\", \"Speaker 3\" and so on.\n");
        if (hints != null && !hints.trim().isEmpty()) {
            p.append("- People expected in this meeting (use these spellings when they match): ").append(hints.trim()).append("\n");
        }
        p.append("\nTRANSCRIPT\n");
        p.append("- Cover the whole meeting from start to end. Do not skip or summarise any part.\n");
        p.append("- One entry per speaking turn, in order, with the start time from the beginning of the meeting recording as mm:ss (or h:mm:ss after one hour).\n");
        if ("english".equals(style)) {
            p.append("- Translate everything into simple English.\n");
        } else {
            p.append("- Keep the words as spoken. The meeting may mix English, Hindi and Marathi. Write English as English. ")
             .append("Write Hindi and Marathi in Roman (English) letters the way people type on WhatsApp, e.g. \"haan, woh order next week tak aa jayega\".\n");
        }
        p.append("- Remove filler like 'umm', 'uh'. If a part is not clear, write [unclear]. Never invent words.\n");
        p.append("\nMINUTES (always in clear, simple English)\n");
        p.append("- title: short meeting title based on what was discussed.\n");
        p.append("- summary: 3 to 5 sentences.\n");
        p.append("- attendees: each person with company/role if mentioned.\n");
        p.append("- discussion: group points by topic. Keep numbers, prices, quantities, dates and specs exactly as said.\n");
        p.append("- decisions: what was agreed.\n");
        p.append("- action_items: task, owner (a speaker label) and due date if said, else \"\".\n");
        p.append("- next_steps: follow-ups or next meeting, if any.\n");
        if (durationMs > 0) {
            p.append("\nThe meeting recording is about ").append(Math.round(durationMs / 60000.0)).append(" minutes long.\n");
        }
        p.append("\nReturn ONLY JSON in exactly this shape:\n");
        p.append("{\"title\":\"\",\"language\":\"languages spoken\",")
         .append("\"speakers\":[{\"name\":\"\",\"identified_by\":\"voice sample | greeting | introduction | not found\"}],")
         .append("\"minutes\":{\"summary\":\"\",\"attendees\":[{\"name\":\"\",\"role\":\"\"}],")
         .append("\"discussion\":[{\"topic\":\"\",\"points\":[\"\"]}],\"decisions\":[\"\"],")
         .append("\"action_items\":[{\"task\":\"\",\"owner\":\"\",\"due\":\"\"}],\"next_steps\":[\"\"]},")
         .append("\"transcript\":[{\"t\":\"00:05\",\"speaker\":\"\",\"text\":\"\"}]}\n");
        p.append("Write the keys in this order (minutes before transcript).\n");
        return p.toString();
    }

    // ---------- Gemini Files API ----------

    private String uploadAndWait(File f, String displayName) throws Exception {
        String mime = "audio/aac";
        // 1) start a resumable upload
        HttpURLConnection c = open(BASE + "/upload/v1beta/files?key=" + enc(apiKey), "POST", 60000);
        c.setRequestProperty("X-Goog-Upload-Protocol", "resumable");
        c.setRequestProperty("X-Goog-Upload-Command", "start");
        c.setRequestProperty("X-Goog-Upload-Header-Content-Length", String.valueOf(f.length()));
        c.setRequestProperty("X-Goog-Upload-Header-Content-Type", mime);
        c.setRequestProperty("Content-Type", "application/json");
        c.setDoOutput(true);
        byte[] meta = new JSONObject().put("file", new JSONObject().put("display_name", displayName))
                .toString().getBytes(StandardCharsets.UTF_8);
        try (OutputStream os = c.getOutputStream()) { os.write(meta); }
        int code = c.getResponseCode();
        if (code >= 300) throw new Exception(friendly(new ApiException(code, readAll(c.getErrorStream()))));
        String uploadUrl = c.getHeaderField("X-Goog-Upload-URL");
        if (uploadUrl == null) uploadUrl = c.getHeaderField("x-goog-upload-url");
        c.disconnect();
        if (uploadUrl == null) throw new Exception("Upload could not start. Please try again.");

        // 2) send the bytes
        HttpURLConnection u = open(uploadUrl, "POST", 10 * 60 * 1000);
        u.setRequestProperty("X-Goog-Upload-Command", "upload, finalize");
        u.setRequestProperty("X-Goog-Upload-Offset", "0");
        u.setRequestProperty("Content-Type", mime);
        u.setDoOutput(true);
        u.setFixedLengthStreamingMode(f.length());
        long total = f.length(), sent = 0;
        int lastPct = -1;
        try (InputStream in = new BufferedInputStream(new FileInputStream(f));
             OutputStream os = u.getOutputStream()) {
            byte[] buf = new byte[64 * 1024];
            int n;
            while ((n = in.read(buf)) > 0) {
                os.write(buf, 0, n);
                sent += n;
                int pct = (int) (sent * 100 / Math.max(1, total));
                if (pct / 10 != lastPct / 10) {
                    lastPct = pct;
                    if (displayName.equals("meeting")) listener.status("Uploading recording… " + pct + "%");
                }
            }
        }
        code = u.getResponseCode();
        if (code >= 300) throw new Exception(friendly(new ApiException(code, readAll(u.getErrorStream()))));
        JSONObject fileObj = new JSONObject(readAll(u.getInputStream())).getJSONObject("file");
        u.disconnect();

        String name = fileObj.getString("name");
        String uri = fileObj.getString("uri");
        String state = fileObj.optString("state", "ACTIVE");

        // 3) wait until Google has processed the audio
        int tries = 0;
        while ("PROCESSING".equals(state) && tries < 90) {
            Thread.sleep(2000);
            tries++;
            HttpURLConnection g = open(BASE + "/v1beta/" + name + "?key=" + enc(apiKey), "GET", 60000);
            if (g.getResponseCode() < 300) {
                state = new JSONObject(readAll(g.getInputStream())).optString("state", "ACTIVE");
            }
            g.disconnect();
        }
        if ("FAILED".equals(state)) throw new Exception("Google could not read this audio file.");
        return uri;
    }

    // ---------- helpers ----------

    private static JSONObject text(String t) throws Exception { return new JSONObject().put("text", t); }

    private static JSONObject file(String uri) throws Exception {
        return new JSONObject().put("file_data",
                new JSONObject().put("mime_type", "audio/aac").put("file_uri", uri));
    }

    private static String extractText(String resp) throws Exception {
        JSONObject o = new JSONObject(resp);
        JSONArray cands = o.optJSONArray("candidates");
        if (cands == null || cands.length() == 0) {
            JSONObject fb = o.optJSONObject("promptFeedback");
            throw new Exception("Gemini returned nothing" + (fb != null ? " (" + fb.optString("blockReason") + ")" : "") + ". Try again.");
        }
        JSONObject cand = cands.getJSONObject(0);
        JSONObject content = cand.optJSONObject("content");
        StringBuilder sb = new StringBuilder();
        if (content != null && content.optJSONArray("parts") != null) {
            JSONArray parts = content.getJSONArray("parts");
            for (int i = 0; i < parts.length(); i++) {
                JSONObject p = parts.getJSONObject(i);
                if (p.optBoolean("thought", false)) continue;
                sb.append(p.optString("text", ""));
            }
        }
        if (sb.length() == 0) throw new Exception("Gemini returned an empty answer (" + cand.optString("finishReason") + "). Try again.");
        JSONObject wrap = new JSONObject();
        wrap.put("text", sb.toString());
        wrap.put("finish", cand.optString("finishReason", ""));
        return wrap.toString();
    }

    private static String friendly(ApiException e) {
        String m = e.getMessage() == null ? "" : e.getMessage();
        String detail = m;
        try { detail = new JSONObject(m).getJSONObject("error").optString("message", m); } catch (Exception ignored) { }
        if (e.code == 400 && detail.toLowerCase().contains("api key")) return "Your Gemini API key is not valid. Check it in Settings.";
        if (e.code == 403) return "This API key is not allowed to use Gemini. Create a new key at aistudio.google.com/apikey.";
        if (e.code == 429) return "Gemini's free limit is used up for now. Try again in a few minutes (or tomorrow).";
        if (e.code == 503 || e.code == 500) return "Gemini is busy right now. Try again in a few minutes.";
        if (e.code == 404) return "Gemini model not found. Clear the model box in Settings to use the default.";
        if (detail.length() > 300) detail = detail.substring(0, 300);
        return "Gemini error " + e.code + ": " + detail;
    }

    private static HttpURLConnection open(String url, String method, int readTimeout) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setRequestMethod(method);
        c.setConnectTimeout(30000);
        c.setReadTimeout(readTimeout);
        return c;
    }

    private static String postJson(String url, String json, int readTimeout) throws Exception {
        HttpURLConnection c;
        try {
            c = open(url, "POST", readTimeout);
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            c.setDoOutput(true);
            byte[] b = json.getBytes(StandardCharsets.UTF_8);
            c.setFixedLengthStreamingMode(b.length);
            try (OutputStream os = c.getOutputStream()) { os.write(b); }
        } catch (UnknownHostException e) {
            throw new Exception("No internet connection.");
        }
        int code = c.getResponseCode();
        if (code >= 300) {
            String err = readAll(c.getErrorStream());
            c.disconnect();
            throw new ApiException(code, err);
        }
        String out = readAll(c.getInputStream());
        c.disconnect();
        return out;
    }

    private static String readAll(InputStream in) throws Exception {
        if (in == null) return "";
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[16 * 1024];
        int n;
        while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
        in.close();
        return bo.toString("UTF-8");
    }

    private static String enc(String s) throws Exception { return URLEncoder.encode(s, "UTF-8"); }
}

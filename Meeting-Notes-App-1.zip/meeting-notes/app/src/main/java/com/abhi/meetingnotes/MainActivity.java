package com.abhi.meetingnotes;

import android.Manifest;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.PowerManager;
import android.provider.MediaStore;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class MainActivity extends Activity {

    private static final String SAMPLE_ID = "__sample";
    private static final Set<String> processing = Collections.synchronizedSet(new HashSet<>());

    private WebView web;
    private MediaPlayer player;
    private String playingId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setTextZoom(100);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Bridge(), "Android");
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("window.onBack ? window.onBack() : false", value -> {
            if (!"true".equals(value)) MainActivity.super.onBackPressed();
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        js("window.onAppResume && window.onAppResume()");
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        boolean mic = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
        js("window.onPermission && window.onPermission(" + mic + ")");
    }

    @Override
    protected void onDestroy() {
        stopPlayer();
        super.onDestroy();
    }

    private void js(String code) {
        runOnUiThread(() -> { if (web != null) web.evaluateJavascript(code, null); });
    }

    private static String q(String s) { return JSONObject.quote(s == null ? "" : s); }

    private File dataFile() { return new File(getFilesDir(), "data.json"); }
    private File audioFile(String id) {
        if (SAMPLE_ID.equals(id)) return new File(getFilesDir(), "voice_sample.aac");
        return new File(new File(getFilesDir(), "audio"), id + ".aac");
    }
    private File resultFile(String id) { return new File(new File(getFilesDir(), "results"), id + ".json"); }

    private static String readFile(File f) {
        if (!f.exists()) return "";
        try (FileInputStream in = new FileInputStream(f)) {
            byte[] b = new byte[(int) f.length()];
            int off = 0, n;
            while (off < b.length && (n = in.read(b, off, b.length - off)) > 0) off += n;
            return new String(b, 0, off, StandardCharsets.UTF_8);
        } catch (Exception e) { return ""; }
    }

    private static boolean writeFile(File f, String content) {
        try {
            if (f.getParentFile() != null) f.getParentFile().mkdirs();
            File tmp = new File(f.getPath() + ".tmp");
            try (FileOutputStream out = new FileOutputStream(tmp)) {
                out.write(content.getBytes(StandardCharsets.UTF_8));
                out.getFD().sync();
            }
            return tmp.renameTo(f);
        } catch (Exception e) { return false; }
    }

    private void stopPlayer() {
        if (player != null) {
            try { player.stop(); } catch (Exception ignored) { }
            player.release();
            player = null;
        }
        playingId = null;
    }

    /** Everything the web UI can call. */
    public class Bridge {

        // ----- storage -----
        @JavascriptInterface public String loadData() { return readFile(dataFile()); }

        @JavascriptInterface public boolean saveData(String json) {
            boolean ok = writeFile(dataFile(), json);
            writeFile(new File(getFilesDir(), "data.backup.json"), json);
            return ok;
        }

        @JavascriptInterface public String loadBackup() { return readFile(new File(getFilesDir(), "data.backup.json")); }

        @JavascriptInterface public String getResult(String id) { return readFile(resultFile(id)); }

        @JavascriptInterface public void deleteMeetingFiles(String id) {
            audioFile(id).delete();
            resultFile(id).delete();
        }

        @JavascriptInterface public long audioSize(String id) { return audioFile(id).length(); }

        @JavascriptInterface public boolean hasSample() { return audioFile(SAMPLE_ID).length() > 2000; }

        // ----- permissions -----
        @JavascriptInterface public boolean hasMic() {
            return checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
        }

        @JavascriptInterface public void requestMic() {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= 33) {
                    requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO,
                            Manifest.permission.POST_NOTIFICATIONS}, 7);
                } else {
                    requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 7);
                }
            });
        }

        // ----- recording -----
        @JavascriptInterface public String startRecording(String id) {
            if (!hasMic()) return "Microphone permission is needed.";
            if (RecorderService.instance != null) return "A recording is already running.";
            stopPlayer();
            File target = SAMPLE_ID.equals(id) ? new File(getFilesDir(), "voice_sample.new.aac") : audioFile(id);
            RecorderService.lastError = null;
            Intent i = new Intent(MainActivity.this, RecorderService.class);
            i.putExtra(RecorderService.EXTRA_PATH, target.getPath());
            i.putExtra(RecorderService.EXTRA_ID, id);
            try {
                startForegroundService(i);
            } catch (Exception e) {
                return "Could not start recording: " + e.getMessage();
            }
            return "";
        }

        @JavascriptInterface public String recStatus() {
            try {
                JSONObject o = new JSONObject();
                RecorderService r = RecorderService.instance;
                o.put("active", r != null);
                if (r != null) {
                    o.put("id", r.getId());
                    o.put("paused", r.isPaused());
                    o.put("ms", r.elapsedMs());
                    o.put("amp", r.amplitude());
                }
                o.put("error", RecorderService.lastError == null ? "" : RecorderService.lastError);
                return o.toString();
            } catch (Exception e) { return "{\"active\":false}"; }
        }

        @JavascriptInterface public boolean pauseRec() {
            RecorderService r = RecorderService.instance;
            return r != null && r.pause();
        }

        @JavascriptInterface public boolean resumeRec() {
            RecorderService r = RecorderService.instance;
            return r != null && r.resume();
        }

        /** Stops recording, returns length in ms (or -1 if nothing was recording). */
        @JavascriptInterface public long stopRec() {
            RecorderService r = RecorderService.instance;
            if (r == null) return -1;
            String id = r.getId();
            String path = r.getPath();
            long ms = r.stopRecording();
            if (SAMPLE_ID.equals(id)) {
                File tmp = new File(path);
                if (tmp.length() > 2000) {
                    File fin = audioFile(SAMPLE_ID);
                    fin.delete();
                    tmp.renameTo(fin);
                } else {
                    tmp.delete();
                }
            }
            return ms;
        }

        // ----- playback -----
        @JavascriptInterface public String play(String id) {
            try {
                if (player != null && id.equals(playingId)) {
                    if (player.isPlaying()) player.pause(); else player.start();
                    return "";
                }
                stopPlayer();
                File f = audioFile(id);
                if (!f.exists()) return "Audio file not found.";
                player = new MediaPlayer();
                player.setDataSource(f.getPath());
                player.prepare();
                player.setOnCompletionListener(mp -> js("window.onPlayEnd && window.onPlayEnd()"));
                player.start();
                playingId = id;
                return "";
            } catch (Exception e) {
                stopPlayer();
                return "Could not play: " + e.getMessage();
            }
        }

        @JavascriptInterface public void stopPlay() { runOnUiThread(MainActivity.this::stopPlayer); }

        @JavascriptInterface public void seek(int ms) {
            runOnUiThread(() -> { if (player != null) player.seekTo(ms); });
        }

        @JavascriptInterface public String playState() {
            try {
                JSONObject o = new JSONObject();
                o.put("id", playingId == null ? "" : playingId);
                if (player != null) {
                    o.put("playing", player.isPlaying());
                    o.put("pos", player.getCurrentPosition());
                    o.put("dur", player.getDuration());
                } else {
                    o.put("playing", false);
                }
                return o.toString();
            } catch (Exception e) { return "{\"playing\":false}"; }
        }

        // ----- AI processing -----
        @JavascriptInterface public boolean isProcessing(String id) { return processing.contains(id); }

        @JavascriptInterface public void process(String id, String apiKey, String userName, String hints,
                                                 String style, String model, double durationMs) {
            if (processing.contains(id)) return;
            processing.add(id);
            new Thread(() -> {
                PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
                PowerManager.WakeLock wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "MeetingNotes:ai");
                wl.acquire(20 * 60 * 1000L);
                try {
                    GeminiClient client = new GeminiClient(apiKey,
                            msg -> js("window.onProcessStatus && window.onProcessStatus(" + q(id) + "," + q(msg) + ")"));
                    File sample = audioFile(SAMPLE_ID);
                    String out = client.process(audioFile(id), sample.length() > 2000 ? sample : null,
                            userName, hints, style, model, (long) durationMs);
                    writeFile(resultFile(id), out);
                    js("window.onProcessDone && window.onProcessDone(" + q(id) + "," + q(out) + ")");
                } catch (UnknownHostException e) {
                    js("window.onProcessError && window.onProcessError(" + q(id) + "," + q("No internet connection.") + ")");
                } catch (Throwable e) {
                    String m = e.getMessage() == null ? e.toString() : e.getMessage();
                    js("window.onProcessError && window.onProcessError(" + q(id) + "," + q(m) + ")");
                } finally {
                    processing.remove(id);
                    if (wl.isHeld()) wl.release();
                }
            }).start();
        }

        // ----- export / share -----
        /** Saves to Downloads/Meeting Notes. Returns the content URI, or "" on failure. */
        @JavascriptInterface public String saveDownload(String fileName, String mime, String content) {
            try {
                ContentResolver cr = getContentResolver();
                ContentValues v = new ContentValues();
                v.put(MediaStore.Downloads.DISPLAY_NAME, fileName);
                v.put(MediaStore.Downloads.MIME_TYPE, mime);
                v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Meeting Notes");
                Uri uri = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                if (uri == null) return "";
                try (OutputStream os = cr.openOutputStream(uri)) {
                    if (os == null) return "";
                    os.write(content.getBytes(StandardCharsets.UTF_8));
                }
                return uri.toString();
            } catch (Exception e) { return ""; }
        }

        @JavascriptInterface public void shareFile(String uri, String mime, String subject) {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType(mime);
                i.putExtra(Intent.EXTRA_STREAM, Uri.parse(uri));
                i.putExtra(Intent.EXTRA_SUBJECT, subject);
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(Intent.createChooser(i, "Share"));
            });
        }

        @JavascriptInterface public void shareText(String subject, String text) {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_SUBJECT, subject);
                i.putExtra(Intent.EXTRA_TEXT, text);
                startActivity(Intent.createChooser(i, "Share"));
            });
        }

        @JavascriptInterface public void openUrl(String url) {
            runOnUiThread(() -> {
                try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch (Exception ignored) { }
            });
        }

        @JavascriptInterface public void keepScreenOn(boolean on) {
            runOnUiThread(() -> {
                if (on) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            });
        }
    }
}

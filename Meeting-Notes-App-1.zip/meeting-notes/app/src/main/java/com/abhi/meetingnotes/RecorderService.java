package com.abhi.meetingnotes;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import android.os.SystemClock;

import java.io.File;

/**
 * Records audio in the foreground so recording keeps going with the screen off.
 * Output: AAC (ADTS) mono, 16 kHz, 48 kbps — about 21 MB per hour.
 */
public class RecorderService extends Service {

    public static final String EXTRA_PATH = "path";
    public static final String EXTRA_ID = "id";
    private static final String CHANNEL = "recording";

    public static volatile RecorderService instance;
    public static volatile String lastError;

    private MediaRecorder recorder;
    private PowerManager.WakeLock wakeLock;
    private String path;
    private String id;
    private long startedAt;      // elapsedRealtime when the current running stretch began
    private long accumulated;    // ms recorded before the current stretch
    private boolean paused;
    private String error;

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) { stopSelf(); return START_NOT_STICKY; }
        if (recorder != null) return START_NOT_STICKY; // already recording
        path = intent.getStringExtra(EXTRA_PATH);
        id = intent.getStringExtra(EXTRA_ID);
        instance = this;

        startForeground(1, buildNotification("Recording meeting…"),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);

        try {
            File f = new File(path);
            if (f.getParentFile() != null) f.getParentFile().mkdirs();
            recorder = Build.VERSION.SDK_INT >= 31 ? new MediaRecorder(this) : new MediaRecorder();
            recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            recorder.setOutputFormat(MediaRecorder.OutputFormat.AAC_ADTS);
            recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            recorder.setAudioChannels(1);
            recorder.setAudioSamplingRate(16000);
            recorder.setAudioEncodingBitRate(48000);
            recorder.setOutputFile(path);
            recorder.prepare();
            recorder.start();
            startedAt = SystemClock.elapsedRealtime();
            accumulated = 0;
            paused = false;
            error = null;
            lastError = null;

            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "MeetingNotes:rec");
            wakeLock.acquire(6 * 60 * 60 * 1000L);
        } catch (Exception e) {
            error = "Could not start the mic: " + e.getMessage();
            lastError = error;
            releaseRecorder();
            instance = null;
            stopForeground(STOP_FOREGROUND_REMOVE);
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    private Notification buildNotification(String text) {
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm.getNotificationChannel(CHANNEL) == null) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "Recording",
                    NotificationManager.IMPORTANCE_LOW);
            nm.createNotificationChannel(ch);
        }
        Intent open = new Intent(this, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        return new Notification.Builder(this, CHANNEL)
                .setSmallIcon(R.drawable.ic_notif)
                .setContentTitle("Meeting Notes")
                .setContentText(text)
                .setOngoing(true)
                .setContentIntent(pi)
                .build();
    }

    private void updateNotification(String text) {
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.notify(1, buildNotification(text));
    }

    public synchronized boolean pause() {
        if (recorder == null || paused) return false;
        try {
            recorder.pause();
            accumulated += SystemClock.elapsedRealtime() - startedAt;
            paused = true;
            updateNotification("Recording paused");
            return true;
        } catch (Exception e) { return false; }
    }

    public synchronized boolean resume() {
        if (recorder == null || !paused) return false;
        try {
            recorder.resume();
            startedAt = SystemClock.elapsedRealtime();
            paused = false;
            updateNotification("Recording meeting…");
            return true;
        } catch (Exception e) { return false; }
    }

    /** Stops and returns the recorded length in ms. */
    public synchronized long stopRecording() {
        long ms = elapsedMs();
        if (recorder != null) {
            try { recorder.stop(); } catch (Exception ignored) { }
        }
        releaseRecorder();
        instance = null;
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
        return ms;
    }

    public synchronized long elapsedMs() {
        if (recorder == null) return accumulated;
        return paused ? accumulated : accumulated + (SystemClock.elapsedRealtime() - startedAt);
    }

    public synchronized int amplitude() {
        if (recorder == null || paused) return 0;
        try { return recorder.getMaxAmplitude(); } catch (Exception e) { return 0; }
    }

    public boolean isPaused() { return paused; }
    public String getId() { return id; }
    public String getPath() { return path; }
    public String getError() { return error; }

    private void releaseRecorder() {
        if (recorder != null) {
            try { recorder.release(); } catch (Exception ignored) { }
            recorder = null;
        }
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        wakeLock = null;
    }

    @Override
    public void onDestroy() {
        if (recorder != null) {
            try { recorder.stop(); } catch (Exception ignored) { }
        }
        releaseRecorder();
        instance = null;
        super.onDestroy();
    }
}
